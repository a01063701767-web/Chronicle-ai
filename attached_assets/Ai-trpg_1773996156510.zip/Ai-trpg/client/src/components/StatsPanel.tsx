import { memo } from "react";
import { motion } from "framer-motion";
import type { Stats, StatChanges } from "@shared/schema";
import { useLang } from "@/lib/i18n";
import { Heart, Sword, Eye, Sparkles, Star } from "lucide-react";

type Props = { stats: Stats; latestChanges?: StatChanges };

const HpBar = memo(function HpBar({ hp, maxHp }: { hp: number; maxHp: number }) {
  const pct   = Math.max(0, Math.min(100, (hp / maxHp) * 100));
  const color = pct > 50 ? "bg-green-500" : pct > 25 ? "bg-amber-500" : "bg-red-500";
  return (
    <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
      <motion.div
        className={`h-full rounded-full ${color}`}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
    </div>
  );
});

const StatPips = memo(function StatPips({ value }: { value: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 10 }, (_, i) => (
        <div
          key={i}
          className={`w-1 h-2.5 rounded-sm transition-colors duration-300 ${
            i < value ? "bg-primary" : "bg-muted"
          }`}
        />
      ))}
    </div>
  );
});

export const StatsPanel = memo(function StatsPanel({ stats, latestChanges = {} }: Props) {
  const { t } = useLang();
  const sl = t.stats;

  const statRows = [
    { key: "strength"   as const, short: sl.strength,   icon: Sword,    value: stats.strength,   change: latestChanges.strength   },
    { key: "cunning"    as const, short: sl.cunning,     icon: Eye,      value: stats.cunning,    change: latestChanges.cunning    },
    { key: "will"       as const, short: sl.will,        icon: Sparkles, value: stats.will,       change: latestChanges.will       },
    { key: "reputation" as const, short: sl.reputation,  icon: Star,     value: stats.reputation, change: latestChanges.reputation },
  ];

  return (
    <div className="border-b border-border/40 bg-background/60 backdrop-blur-sm">
      <div className="max-w-3xl mx-auto px-4 py-2.5 space-y-2">

        {/* HP row */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 shrink-0">
            <Heart className={`w-3.5 h-3.5 ${stats.hp < 20 ? "text-red-400 animate-pulse" : "text-primary"}`} />
            <span className="text-xs font-medium tabular-nums">
              <motion.span
                key={stats.hp}
                initial={{ scale: 1.3 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.25 }}
                className={`inline-block ${
                  stats.hp < 20 ? "text-red-400" : stats.hp < 40 ? "text-amber-400" : "text-foreground/80"
                }`}
              >
                {stats.hp}
              </motion.span>
              <span className="text-muted-foreground">/{stats.maxHp}</span>
            </span>
            {!!latestChanges.hp && (
              <motion.span
                key={`hp-${latestChanges.hp}`}
                initial={{ opacity: 1, x: 0 }}
                animate={{ opacity: 0, x: 6 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                className={`text-[10px] font-bold ${latestChanges.hp > 0 ? "text-green-400" : "text-red-400"}`}
              >
                {latestChanges.hp > 0 ? `+${latestChanges.hp}` : latestChanges.hp}
              </motion.span>
            )}
          </div>
          <div className="flex-1">
            <HpBar hp={stats.hp} maxHp={stats.maxHp} />
          </div>
        </div>

        {/* Other stats */}
        <div className="grid grid-cols-4 gap-2">
          {statRows.map(({ key, short, icon: Icon, value, change }) => (
            <div key={key} className="relative space-y-1">
              <div className="flex items-center gap-1">
                <Icon className="w-2.5 h-2.5 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground">{short}</span>
                <motion.span
                  key={`${key}-${value}`}
                  initial={{ scale: 1.2 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.2 }}
                  className="text-[10px] font-semibold text-foreground/80 ml-auto tabular-nums"
                >
                  {value}
                </motion.span>
                {!!change && (
                  <motion.span
                    key={`${key}-delta-${change}`}
                    initial={{ opacity: 1, y: 0 }}
                    animate={{ opacity: 0, y: -10 }}
                    transition={{ duration: 1.2, ease: "easeOut" }}
                    className={`absolute -top-2 right-0 text-[9px] font-bold ${
                      change > 0 ? "text-green-400" : "text-red-400"
                    }`}
                  >
                    {change > 0 ? `+${change}` : change}
                  </motion.span>
                )}
              </div>
              <StatPips value={value} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
});
