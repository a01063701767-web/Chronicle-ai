import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Sword, ScrollText, Skull } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { LangToggle } from "@/components/LangToggle";

const GENRE_KEYS = ["fantasy", "dark fantasy", "sci-fi", "horror", "western"] as const;

const CLASSES = {
  en: [
    { name: "Warrior",     hint: "Sole survivor of a slaughtered regiment. The fortress is falling." },
    { name: "Rogue",       hint: "You stole something you shouldn't have. Dawn is one hour away." },
    { name: "Mage",        hint: "Trapped inside a sealed tower. Something inside woke up." },
    { name: "Paladin",     hint: "Sent to investigate a cathedral gone silent. Something breathes in the dark." },
    { name: "Ranger",      hint: "Three days tracking a creature. The trail ends at a strange symbol." },
    { name: "Necromancer", hint: "Your ritual went wrong. Something older answered. The crypt sealed itself." },
    { name: "Bard",        hint: "You overheard a war secret. Both generals saw your face." },
    { name: "Druid",       hint: "The land screamed three nights ago. You followed the wound here." },
  ],
  ko: [
    { name: "전사",       hint: "부대가 전멸했고, 살아남은 건 당신뿐. 요새가 무너지고 있다." },
    { name: "도적",       hint: "훔쳐선 안 될 것을 훔쳤다. 새벽까지 한 시간." },
    { name: "마법사",     hint: "봉인된 탑에 갇혔다. 주문이 무언가를 깨웠다." },
    { name: "성기사",     hint: "기도가 침묵한 성당을 조사하러 왔다. 어둠 속에서 무언가가 숨 쉰다." },
    { name: "레인저",     hint: "사흘째 추적. 발자국이 이상한 문양 앞에서 끊겼다." },
    { name: "사령술사",   hint: "의식이 틀어졌다. 훨씬 오래된 것이 응답했다. 납골당이 봉인됐다." },
    { name: "음유시인",   hint: "전쟁을 끝낼 비밀을 엿들었다. 두 장군이 당신의 얼굴을 봤다." },
    { name: "드루이드",   hint: "사흘 전 밤 땅이 비명 질렀다. 상처의 근원을 따라 여기까지 왔다." },
  ],
};

export default function Home() {
  const [, setLocation] = useLocation();
  const { lang, t } = useLang();
  const [name, setName] = useState("");
  const [charClass, setCharClass] = useState("");
  const [genre, setGenre] = useState<typeof GENRE_KEYS[number]>("fantasy");

  const classes = CLASSES[lang];
  const selectedClassHint = classes.find((c) => c.name === charClass)?.hint;

  useEffect(() => {
    setCharClass("");
  }, [lang]);

  const startMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/game/start", {
        genre,
        characterName: name || undefined,
        characterClass: charClass || undefined,
        lang,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setLocation(`/game/${data.sessionId}`);
    },
  });

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <div className="absolute top-4 right-4">
        <LangToggle />
      </div>

      <div className="w-full max-w-lg space-y-10">
        <div className="text-center space-y-4">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Skull className="w-16 h-16 text-primary opacity-20 absolute -top-2 -left-2 animate-float" style={{ animationDelay: "1s" }} />
              <Sword className="w-20 h-20 text-primary animate-float" />
              <Skull className="w-12 h-12 text-primary opacity-20 absolute -bottom-1 -right-1 animate-float" style={{ animationDelay: "0.5s" }} />
            </div>
          </div>
          <h1 className="text-5xl font-bold golden-text tracking-tight">
            {t.appName}
          </h1>
          <p className="text-muted-foreground text-lg">
            {t.appTagline}
          </p>
          <div className="flex justify-center gap-2 text-xs text-muted-foreground/60">
            <ScrollText className="w-3 h-3 mt-0.5" />
            <span>{t.appSub}</span>
          </div>
        </div>

        <div className="bg-card border border-card-border rounded-lg p-6 space-y-5 shadow-xl">
          <div className="space-y-1.5">
            <Label htmlFor="char-name" className="text-sm text-foreground/80">{t.characterName}</Label>
            <Input
              id="char-name"
              data-testid="input-character-name"
              placeholder={t.characterNamePlaceholder}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-muted/40 border-input focus:border-primary/50"
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm text-foreground/80">{t.classLabel}</Label>
            <Select onValueChange={setCharClass} value={charClass}>
              <SelectTrigger data-testid="select-class" className="bg-muted/40 border-input">
                <SelectValue placeholder={t.classPlaceholder} />
              </SelectTrigger>
              <SelectContent>
                {classes.map((c) => (
                  <SelectItem key={c.name} value={c.name} data-testid={`option-class-${c.name}`}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedClassHint && (
              <p className="text-xs text-muted-foreground/70 italic pl-1 mt-1">
                {selectedClassHint}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label className="text-sm text-foreground/80">{t.genreLabel}</Label>
            <div className="grid grid-cols-1 gap-2">
              {GENRE_KEYS.map((g) => {
                const genreInfo = t.genres[g];
                return (
                  <button
                    key={g}
                    data-testid={`genre-${g.replace(" ", "-")}`}
                    onClick={() => setGenre(g)}
                    className={`text-left px-4 py-3 rounded-md border transition-all ${
                      genre === g
                        ? "border-primary/60 bg-primary/10 text-foreground"
                        : "border-border bg-muted/30 text-muted-foreground hover:border-border/80 hover:bg-muted/50"
                    }`}
                  >
                    <div className="text-sm font-medium">{genreInfo.label}</div>
                    <div className="text-xs opacity-70 mt-0.5">{genreInfo.description}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <Button
            data-testid="button-start-game"
            className="w-full h-12 text-base font-semibold animate-pulse-glow"
            onClick={() => startMutation.mutate()}
            disabled={startMutation.isPending}
          >
            {startMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {t.beginningButton}
              </>
            ) : (
              <>
                <Sword className="w-4 h-4 mr-2" />
                {t.beginButton}
              </>
            )}
          </Button>

          {startMutation.isError && (
            <p className="text-destructive text-sm text-center" data-testid="text-start-error">
              {t.startError}
            </p>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground/40">
          {t.poweredBy}
        </p>
      </div>
    </div>
  );
}
