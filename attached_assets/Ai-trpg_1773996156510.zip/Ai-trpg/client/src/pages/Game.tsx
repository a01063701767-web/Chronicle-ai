import { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";
import { useParams, useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Loader2, ArrowLeft, BookOpen, Scroll, Trophy, Skull, ChevronDown, Dices, User,
} from "lucide-react";
import type { StoryResponse, Stats, StatChanges, RollResult, DiceOutcome } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";
import { useLang } from "@/lib/i18n";
import { LangToggle } from "@/components/LangToggle";
import { StatsPanel } from "@/components/StatsPanel";

// ─── Types ────────────────────────────────────────────────────────────────────

type StoryBeat = {
  id: number;
  narration: string;
  sentences: string[];
  choices: string[];
  chosenIndex?: number;
  chosenText?: string;
  roll?: RollResult;
  statChanges?: StatChanges;
  isEnding?: boolean;
};

// ─── Utilities ────────────────────────────────────────────────────────────────

function splitSentences(text: string): string[] {
  const parts = text.match(/[^.!?。\n]+[.!?。]*\n?/g);
  if (!parts) return [text];
  const clean = parts.map((s) => s.trim()).filter(Boolean);
  return clean.length ? clean : [text];
}

// ─── Typewriter ───────────────────────────────────────────────────────────────

const TYPING_SPEED_MS = 28;

const Typewriter = memo(function Typewriter({
  text,
  skip,
  onComplete,
}: {
  text: string;
  skip: boolean;
  onComplete: () => void;
}) {
  const [displayed, setDisplayed] = useState("");
  const idxRef        = useRef(0);
  const doneRef       = useRef(false);
  const intervalRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  // Reset on new text
  useEffect(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setDisplayed("");
    idxRef.current  = 0;
    doneRef.current = false;

    intervalRef.current = setInterval(() => {
      if (doneRef.current) { clearInterval(intervalRef.current!); return; }
      idxRef.current++;
      setDisplayed(text.slice(0, idxRef.current));
      if (idxRef.current >= text.length) {
        clearInterval(intervalRef.current!);
        doneRef.current = true;
        onCompleteRef.current();
      }
    }, TYPING_SPEED_MS);

    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [text]);

  // Skip to end
  useEffect(() => {
    if (skip && !doneRef.current) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      doneRef.current = true;
      setDisplayed(text);
      onCompleteRef.current();
    }
  }, [skip, text]);

  const done = displayed.length >= text.length;
  return (
    <span>
      {displayed}
      {!done && (
        <span className="inline-block w-0.5 h-4 bg-primary/70 ml-0.5 animate-pulse align-middle" />
      )}
    </span>
  );
});

// ─── Dice roll card ───────────────────────────────────────────────────────────

const OUTCOME_STYLE: Record<DiceOutcome, { color: string; bg: string; border: string }> = {
  critical_failure: { color: "text-red-400",   bg: "bg-red-950/40",    border: "border-red-500/40"    },
  failure:          { color: "text-orange-400", bg: "bg-orange-950/30", border: "border-orange-500/30" },
  partial:          { color: "text-amber-400",  bg: "bg-amber-950/30",  border: "border-amber-500/30"  },
  success:          { color: "text-green-400",  bg: "bg-green-950/30",  border: "border-green-500/30"  },
  critical_success: { color: "text-yellow-300", bg: "bg-yellow-950/30", border: "border-yellow-400/50" },
};

const DiceRollCard = memo(function DiceRollCard({ roll }: { roll: RollResult }) {
  const { t }    = useLang();
  const d        = t.dice;
  const style    = OUTCOME_STYLE[roll.outcome];
  const statLabel     = (d.statNames as Record<string, string>)[roll.stat] ?? roll.stat.toUpperCase();
  const outcomeLabel  = (d.outcomes  as Record<string, string>)[roll.outcome] ?? roll.outcome;
  const modSign       = roll.modifier >= 0 ? `+${roll.modifier}` : `${roll.modifier}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: -6, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={`flex items-center gap-3 px-4 py-2.5 rounded-lg border ${style.bg} ${style.border}`}
      data-testid="dice-roll-card"
    >
      <motion.div initial={{ rotate: -30 }} animate={{ rotate: 0 }} transition={{ duration: 0.4, ease: "easeOut" }}>
        <Dices className={`w-4 h-4 shrink-0 ${style.color}`} />
      </motion.div>

      <div className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground/70">
        <span className="text-foreground/60">d20</span>
        <motion.span
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
          className="text-foreground/90 font-bold text-sm"
        >{roll.raw}</motion.span>
        <span className="text-muted-foreground/40">·</span>
        <span>{statLabel}</span>
        <motion.span
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.18 }}
          className={roll.modifier >= 0 ? "text-green-400/80" : "text-red-400/80"}
        >{modSign}</motion.span>
        <span className="text-muted-foreground/40">=</span>
        <motion.span
          initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.25, type: "spring", stiffness: 300 }}
          className={`font-bold text-sm ${style.color}`}
        >{roll.total}</motion.span>
      </div>

      <span className={`ml-auto text-xs font-semibold tracking-wide ${style.color}`}>
        {outcomeLabel}
      </span>
    </motion.div>
  );
});

// ─── Past beat (memoized — never re-renders once rendered) ─────────────────

const PastBeat = memo(function PastBeat({
  beat, beatIdx, choseLabel,
}: {
  beat: StoryBeat; beatIdx: number; choseLabel: string;
}) {
  return (
    <div className="space-y-4" data-testid={`beat-${beat.id}`}>
      {beat.roll && beatIdx > 0 && <DiceRollCard roll={beat.roll} />}
      <div className="space-y-3">
        {beat.sentences.map((s, i) => (
          <p key={i} className="story-text text-foreground/90 leading-relaxed">{s}</p>
        ))}
      </div>
      {beat.chosenText && (
        <div className="pl-4 border-l-2 border-primary/30" data-testid={`text-chosen-${beat.id}`}>
          <p className="text-muted-foreground text-sm italic">
            {choseLabel} <span className="text-foreground/70">{beat.chosenText}</span>
          </p>
        </div>
      )}
    </div>
  );
});

// ─── Game ─────────────────────────────────────────────────────────────────────

export default function Game() {
  const { id }       = useParams<{ id: string }>();
  const sessionId    = parseInt(id);
  const [, setLocation] = useLocation();
  const { lang, t }  = useLang();
  const bottomRef    = useRef<HTMLDivElement>(null);
  const beatIdRef    = useRef(0);        // avoids extra state for id generation
  const changeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [beats,          setBeats]         = useState<StoryBeat[]>([]);
  const [isEnded,        setIsEnded]        = useState(false);
  const [revealedCount,  setRevealedCount]  = useState(1);
  const [choicesVisible, setChoicesVisible] = useState(false);
  const [stats,          setStats]          = useState<Stats | null>(null);
  const [latestChanges,  setLatestChanges]  = useState<StatChanges>({});
  const [isTyping,       setIsTyping]       = useState(false);
  const [skipTyping,     setSkipTyping]     = useState(false);
  const [playerMeta,     setPlayerMeta]     = useState<{ name: string; characterClass: string } | null>(null);

  // Derived — memoized to avoid recomputation
  const currentBeat      = beats[beats.length - 1];
  const currentSentences = useMemo(() => currentBeat?.sentences ?? [], [currentBeat]);
  const allRevealed      = revealedCount >= currentSentences.length;
  const isDead           = stats !== null && stats.hp <= 0;
  const turnCount        = beats.length;
  const showTapHint      = isTyping  && !false /* choiceMutation.isPending checked below */;
  const showChoiceHint   = !isTyping && allRevealed && !choicesVisible
                           && !currentBeat?.isEnding && !currentBeat?.chosenText;

  const { data: gameData, isLoading } = useQuery({
    queryKey: ["/api/game", sessionId],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/game/${sessionId}`);
      return res.json();
    },
    enabled: !!sessionId,
  });

  useEffect(() => {
    if (!gameData || beats.length > 0) return;
    if (gameData.stats)      setStats(gameData.stats);
    if (gameData.playerMeta) setPlayerMeta(gameData.playerMeta);
    if (gameData.entries?.length > 0) {
      const lastNarration = [...gameData.entries]
        .reverse()
        .find((e: any) => e.entryType === "narration");
      if (lastNarration) {
        const data      = JSON.parse(lastNarration.content);
        const sentences = splitSentences(data.narration);
        setBeats([{
          id: beatIdRef.current++,
          narration: data.narration,
          sentences,
          choices: data.choices || [],
          isEnding: data.isEnding,
        }]);
        setRevealedCount(1);
        setIsTyping(true);
        if (data.isEnding) setIsEnded(true);
      }
    }
  }, [gameData]);

  const handleTypingComplete = useCallback(() => {
    setIsTyping(false);
    setSkipTyping(false);
  }, []);

  const scheduleChangeClear = useCallback(() => {
    if (changeTimerRef.current) clearTimeout(changeTimerRef.current);
    changeTimerRef.current = setTimeout(() => setLatestChanges({}), 2500);
  }, []);

  const choiceMutation = useMutation({
    mutationFn: async ({ choiceIndex, choiceText }: { choiceIndex: number; choiceText: string }) => {
      const res = await apiRequest("POST", `/api/game/${sessionId}/choice`, {
        choiceIndex, choiceText, lang,
      });
      return res.json() as Promise<StoryResponse & { stats?: Stats }>;
    },
    onSuccess: (data, variables) => {
      if (data.stats) {
        setLatestChanges(data.statChanges ?? {});
        setStats(data.stats);
        scheduleChangeClear();
      }
      setBeats((prev) => {
        const updated = prev.map((b, i) =>
          i === prev.length - 1
            ? { ...b, chosenIndex: variables.choiceIndex, chosenText: variables.choiceText }
            : b
        );
        return [
          ...updated,
          {
            id:        beatIdRef.current++,
            narration: data.narration,
            sentences: splitSentences(data.narration),
            choices:   data.choices || [],
            roll:      data.roll,
            statChanges: data.statChanges,
            isEnding:  data.isEnding,
          },
        ];
      });
      setRevealedCount(1);
      setChoicesVisible(false);
      setIsTyping(true);
      setSkipTyping(false);
      if (data.isEnding) setIsEnded(true);
    },
  });

  const advanceSentence = useCallback(() => {
    if (choiceMutation.isPending) return;
    if (isTyping)      { setSkipTyping(true); return; }
    if (!allRevealed)  {
      setRevealedCount((c) => Math.min(c + 1, currentSentences.length));
      setIsTyping(true);
      setSkipTyping(false);
      return;
    }
    if (!choicesVisible && !currentBeat?.isEnding && !currentBeat?.chosenText) {
      setChoicesVisible(true);
    }
  }, [isTyping, allRevealed, choicesVisible, currentBeat, currentSentences.length, choiceMutation.isPending]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [revealedCount, choicesVisible, beats.length, choiceMutation.isPending, isTyping]);

  // cleanup timer on unmount
  useEffect(() => () => { if (changeTimerRef.current) clearTimeout(changeTimerRef.current); }, []);

  const isPending = choiceMutation.isPending;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto" />
          <p className="text-muted-foreground animate-pulse">{t.loadingStory}</p>
        </div>
      </div>
    );
  }

  const pastBeats  = beats.slice(0, -1);
  const activeBeat = beats[beats.length - 1];

  return (
    <div
      className="min-h-screen flex flex-col select-none"
      data-testid="game-screen"
      onClick={advanceSentence}
    >
      {/* ── Header ── */}
      <header
        className="sticky top-0 z-10 border-b border-border/50 bg-background/80 backdrop-blur-sm"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between gap-2">
          {/* Left: back */}
          <button
            data-testid="button-back-home"
            onClick={() => setLocation("/")}
            className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">{t.newChronicle}</span>
          </button>

          {/* Center: player info + turn */}
          <div className="flex flex-col items-center min-w-0">
            {playerMeta && (playerMeta.name || playerMeta.characterClass) && (
              <div className="flex items-center gap-1.5 text-xs text-foreground/70 font-medium truncate max-w-[200px]">
                <User className="w-3 h-3 text-primary/60 shrink-0" />
                {playerMeta.name && (
                  <span className="truncate" data-testid="text-player-name">{playerMeta.name}</span>
                )}
                {playerMeta.name && playerMeta.characterClass && (
                  <span className="text-muted-foreground/40">·</span>
                )}
                {playerMeta.characterClass && (
                  <span className="text-muted-foreground/80 truncate" data-testid="text-player-class">
                    {playerMeta.characterClass}
                  </span>
                )}
              </div>
            )}
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                <span data-testid="text-turn-count">{t.turnLabel} {turnCount}</span>
              </div>
              {isEnded && (
                <div className="flex items-center gap-1 text-primary font-medium">
                  <Trophy className="w-3 h-3" />
                  <span className="hidden sm:inline">{t.chronicleComplete}</span>
                </div>
              )}
            </div>
          </div>

          {/* Right: lang toggle */}
          <div className="shrink-0">
            <LangToggle />
          </div>
        </div>
      </header>

      {/* ── Stats panel ── */}
      {stats && (
        <div onClick={(e) => e.stopPropagation()}>
          <StatsPanel stats={stats} latestChanges={latestChanges} />
        </div>
      )}

      {/* ── Story content ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-8 space-y-10">

          {/* Opening divider */}
          {beats.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground/60">
              <Scroll className="w-3 h-3 shrink-0" />
              <span>{t.chronicleBegins}</span>
              <div className="flex-1 h-px bg-border/50" />
            </div>
          )}

          {/* Past beats — memoized, never re-render */}
          {pastBeats.map((beat, i) => (
            <PastBeat key={beat.id} beat={beat} beatIdx={i} choseLabel={t.choseLabel} />
          ))}

          {/* Active beat */}
          {activeBeat && (() => {
            const beatIdx        = beats.length - 1;
            const visibleSentences = activeBeat.sentences.slice(0, revealedCount);

            return (
              <motion.div
                key={activeBeat.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                className="space-y-4"
                data-testid={`beat-${activeBeat.id}`}
              >
                {/* Dice card for non-first beats */}
                {activeBeat.roll && beatIdx > 0 && (
                  <div onClick={(e) => e.stopPropagation()}>
                    <DiceRollCard roll={activeBeat.roll} />
                  </div>
                )}

                {/* Sentences with typewriter on last */}
                <div className="space-y-3">
                  {visibleSentences.map((sentence, sIdx) => {
                    const isActive = sIdx === revealedCount - 1;
                    return (
                      <motion.p
                        key={`${activeBeat.id}-${sIdx}`}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.2 }}
                        className="story-text text-foreground/90 leading-relaxed"
                        data-testid={sIdx === 0 ? `text-narration-${activeBeat.id}` : undefined}
                      >
                        {isActive ? (
                          <Typewriter
                            text={sentence}
                            skip={skipTyping}
                            onComplete={handleTypingComplete}
                          />
                        ) : sentence}
                      </motion.p>
                    );
                  })}
                </div>

                {/* Ending card */}
                {activeBeat.isEnding && allRevealed && !isTyping && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2 }}
                    className={`p-4 rounded-lg border text-center ${
                      isDead ? "border-red-500/30 bg-red-950/20" : "border-primary/30 bg-primary/5"
                    }`}
                    data-testid="text-ending"
                  >
                    {isDead ? (
                      <>
                        <Skull className="w-8 h-8 text-red-400 mx-auto mb-2" />
                        <p className="text-red-400 font-semibold text-sm">{t.deathTitle}</p>
                        <p className="text-muted-foreground text-xs mt-1">{t.deathSubtitle}</p>
                      </>
                    ) : (
                      <>
                        <Trophy className="w-8 h-8 text-primary mx-auto mb-2" />
                        <p className="text-primary font-semibold text-sm">{t.endingTitle}</p>
                        <p className="text-muted-foreground text-xs mt-1">{t.endingSubtitle}</p>
                      </>
                    )}
                  </motion.div>
                )}

                {/* Chosen label */}
                {activeBeat.chosenText && (
                  <div className="pl-4 border-l-2 border-primary/30" data-testid={`text-chosen-${activeBeat.id}`}>
                    <p className="text-muted-foreground text-sm italic">
                      {t.choseLabel} <span className="text-foreground/70">{activeBeat.chosenText}</span>
                    </p>
                  </div>
                )}

                {/* Choice buttons */}
                {choicesVisible && !isTyping && !activeBeat.isEnding && !activeBeat.chosenText && activeBeat.choices.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-3 pt-2"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <p className="text-xs text-muted-foreground/60 uppercase tracking-widest">
                      {t.choicePrompt}
                    </p>
                    <div className="space-y-2">
                      {activeBeat.choices.map((choice, idx) => (
                        <button
                          key={idx}
                          data-testid={`choice-${idx}`}
                          disabled={isPending}
                          onClick={() => choiceMutation.mutate({ choiceIndex: idx, choiceText: choice })}
                          className="choice-card w-full text-left px-5 py-4 rounded-lg border border-border/60 bg-card hover:bg-card/80 group disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <div className="flex items-start gap-3">
                            <span className="text-primary/60 text-xs font-mono mt-0.5 group-hover:text-primary transition-colors">
                              {String.fromCharCode(65 + idx)}.
                            </span>
                            <span className="text-foreground/85 text-sm leading-relaxed">{choice}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })()}

          {/* Loading dots */}
          {isPending && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="flex items-center gap-3 text-muted-foreground"
              data-testid="loading-story"
            >
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-1.5 h-1.5 rounded-full bg-primary/60"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </div>
              <span className="text-sm italic">{t.loadingStory}</span>
            </motion.div>
          )}

          {choiceMutation.isError && (
            <div className="flex items-center gap-2 text-destructive text-sm" data-testid="text-choice-error">
              <Skull className="w-4 h-4" />
              <span>{t.choiceError}</span>
            </div>
          )}

          {/* New chronicle */}
          {isEnded && allRevealed && !isTyping && (
            <div className="pb-8 text-center" onClick={(e) => e.stopPropagation()}>
              <Button
                data-testid="button-new-chronicle"
                variant="outline"
                onClick={() => setLocation("/")}
                className="border-primary/30 text-primary hover:bg-primary/10"
              >
                <BookOpen className="w-4 h-4 mr-2" />
                {t.beginNewChronicle}
              </Button>
            </div>
          )}

          <div ref={bottomRef} className="h-4" />
        </div>
      </div>

      {/* ── Tap hint ── */}
      <AnimatePresence>
        {(showTapHint || showChoiceHint) && !isPending && (
          <motion.div
            key={showTapHint ? "tap" : "choice"}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 6 }}
            transition={{ duration: 0.25 }}
            className="sticky bottom-0 pointer-events-none flex justify-center pb-5 pt-2 bg-gradient-to-t from-background via-background/80 to-transparent"
          >
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground/50">
              <motion.div animate={{ y: [0, 3, 0] }} transition={{ duration: 1.2, repeat: Infinity }}>
                <ChevronDown className="w-3.5 h-3.5" />
              </motion.div>
              <span>{showTapHint ? t.tapToContinue : t.tapForChoices}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
