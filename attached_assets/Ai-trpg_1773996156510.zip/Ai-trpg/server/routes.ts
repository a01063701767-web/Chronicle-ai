import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import type { Stats, StatChanges, RollResult, DiceOutcome } from "@shared/schema";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

// ─── Dice system ──────────────────────────────────────────────────────────────

function rollD20(): number {
  return Math.floor(Math.random() * 20) + 1;
}

function statModifier(statValue: number): number {
  return Math.floor((statValue - 5) / 2); // range: -2 (stat 1) to +2 (stat 9-10)
}

function outcomeFromTotal(total: number): DiceOutcome {
  if (total <= 1)  return "critical_failure";
  if (total <= 6)  return "failure";
  if (total <= 13) return "partial";
  if (total <= 19) return "success";
  return "critical_success";
}

const STRENGTH_KEYWORDS = [
  "fight","attack","strike","force","push","break","charge","combat","hit","bash",
  "block","shield","smash","punch","kick","rush","assault","wrestle","overpower",
  "싸우","공격","강제","밀어","부수","돌격","전투","막아","방패","때려","강행",
];
const CUNNING_KEYWORDS = [
  "sneak","hide","steal","lie","deceive","trick","persuade","pick","unlock","shadow",
  "escape","bluff","slip","conceal","distract","bribe","forge","impersonate","infiltrate",
  "숨어","훔쳐","속여","기만","설득","자물쇠","탈출","위장","침투","뇌물","분산",
];
const WILL_KEYWORDS = [
  "cast","magic","spell","resist","endure","focus","meditate","channel","banish","summon",
  "enchant","curse","ritual","ward","sense","probe","mind","psychic","willpower","arcane",
  "주문","마법","시전","저항","견뎌","집중","명상","소환","봉인","정신","의지","영적",
];
const REPUTATION_KEYWORDS = [
  "speak","negotiate","command","lead","inspire","threaten","appeal","rally","convince",
  "authority","presence","reputation","name","fame","dignity","honor","barter","demand",
  "말해","협상","지휘","이끌","고무","위협","호소","권위","명성","존엄","설득",
];

function detectStat(
  choiceText: string,
  stats: Stats
): { stat: keyof Omit<Stats, "hp" | "maxHp">; statValue: number } {
  const lower = choiceText.toLowerCase();
  const score = {
    strength:   STRENGTH_KEYWORDS.filter((k) => lower.includes(k)).length,
    cunning:    CUNNING_KEYWORDS.filter((k) => lower.includes(k)).length,
    will:       WILL_KEYWORDS.filter((k) => lower.includes(k)).length,
    reputation: REPUTATION_KEYWORDS.filter((k) => lower.includes(k)).length,
  };
  // highest keyword match wins; tie → use highest stat value
  const best = (["strength", "cunning", "will", "reputation"] as const)
    .reduce((a, b) => {
      if (score[a] !== score[b]) return score[a] > score[b] ? a : b;
      return stats[a] >= stats[b] ? a : b;
    });
  return { stat: best, statValue: stats[best] };
}

function computeRoll(choiceText: string, stats: Stats): RollResult {
  const { stat, statValue } = detectStat(choiceText, stats);
  const raw = rollD20();
  const modifier = statModifier(statValue);
  const total = Math.max(1, Math.min(20, raw + modifier));
  const outcome = outcomeFromTotal(total);
  return { raw, stat, statValue, modifier, total, outcome };
}

// ─── Prompts ──────────────────────────────────────────────────────────────────

const SYSTEM_PROMPT_EN = `You are a storyteller for a dark fantasy RPG with a dice-based stat system.

NARRATION RULES:
- Write in second person ("You...")
- Narration: exactly 3 to 5 sentences, direct and vivid, no filler
- Always provide exactly 3 choices, each one sentence, specific and actionable
- Choices must feel meaningfully different (aggressive / cautious / clever)
- After 8-12 turns, end with isEnding: true and no choices
- NEVER mention being an AI

DICE & OUTCOME:
You will receive a DICE ROLL section telling you the result of the player's action.
You MUST reflect this outcome in the narration:
- CRITICAL FAILURE: Everything goes catastrophically wrong. Maximum consequence, unexpected disaster.
- FAILURE: The attempt fails clearly. A new problem or danger emerges.
- PARTIAL SUCCESS: Achieve part of the goal, but with a significant cost, complication, or twist.
- SUCCESS: Clear success. The action works as intended, story advances positively.
- CRITICAL SUCCESS: Exceptional result. Something extra or surprising happens in the player's favor.
The narration must make the outcome feel earned and logical given the player's stats and situation.

STAT SYSTEM:
Adjust statChanges to reflect consequences. Ranges: hp 0-maxHp, others 1-10.
- hp: -25 to +15 based on danger/recovery
- strength/cunning/will: ±1 for meaningful growth moments
- reputation: ±1 to ±2 for social/visible events
- If hp reaches 0: set isEnding: true, write a death scene

ALWAYS respond with valid JSON only, no markdown:
{
  "narration": "...",
  "choices": ["...", "...", "..."],
  "statChanges": { "hp": 0, "strength": 0, "cunning": 0, "will": 0, "reputation": 0 },
  "isEnding": false
}`;

const SYSTEM_PROMPT_KO = `당신은 주사위 기반 스탯 시스템이 있는 다크 판타지 RPG의 스토리텔러입니다.

서사 규칙:
- 2인칭("당신은..." 또는 "당신이...")으로 작성
- 서사: 정확히 3~5문장, 직접적이고 생동감 있게, 군더더기 없이
- 항상 정확히 3개의 선택지, 각각 한 문장, 구체적인 행동
- 선택지는 명확히 다른 방향 (공격적 / 신중한 / 영리한)
- 8~12턴 후 isEnding: true로 마무리
- AI임을 절대 언급 금지
- 모든 내용을 한국어로 작성

주사위 & 결과:
DICE ROLL 항목에서 플레이어 행동의 결과를 확인합니다.
이 결과를 서사에 반드시 반영해야 합니다:
- 대실패: 모든 것이 최악으로 흘러갑니다. 최대 피해, 예상치 못한 재앙.
- 실패: 시도가 명확히 실패합니다. 새로운 문제나 위험이 발생합니다.
- 부분 성공: 목표의 일부를 달성하지만, 대가나 복잡한 상황이 따릅니다.
- 성공: 명확한 성공. 행동이 의도대로 효과를 발휘합니다.
- 대성공: 탁월한 결과. 플레이어에게 유리한 예상 밖의 일이 일어납니다.
서사는 플레이어의 스탯과 상황을 고려하여 결과가 자연스럽게 느껴지도록 해야 합니다.

스탯 시스템:
결과에 따라 statChanges를 조정합니다. 범위: hp 0~maxHp, 나머지 1~10.
- hp: -25 ~ +15 (위험도/회복에 따라)
- strength/cunning/will: ±1 (의미 있는 성장 순간)
- reputation: ±1 ~ ±2 (사회적/공개적 사건)
- hp가 0이 되면: isEnding: true, 사망 장면 작성

마크다운 없이 유효한 JSON만 응답:
{
  "narration": "...",
  "choices": ["...", "...", "..."],
  "statChanges": { "hp": 0, "strength": 0, "cunning": 0, "will": 0, "reputation": 0 },
  "isEnding": false
}`;

const OUTCOME_CONTEXT_EN: Record<DiceOutcome, string> = {
  critical_failure: "CRITICAL FAILURE — everything goes catastrophically wrong",
  failure:          "FAILURE — the attempt clearly fails, a new problem emerges",
  partial:          "PARTIAL SUCCESS — partial achievement with a cost or complication",
  success:          "SUCCESS — the action works as intended",
  critical_success: "CRITICAL SUCCESS — exceptional outcome, something extra happens",
};

const OUTCOME_CONTEXT_KO: Record<DiceOutcome, string> = {
  critical_failure: "대실패 — 모든 것이 최악으로 흘러갑니다",
  failure:          "실패 — 시도가 명확히 실패하고, 새 문제가 발생합니다",
  partial:          "부분 성공 — 일부 달성, 하지만 대가나 복잡한 상황이 따릅니다",
  success:          "성공 — 행동이 의도대로 효과를 발휘합니다",
  critical_success: "대성공 — 탁월한 결과, 예상 밖의 행운이 따릅니다",
};

// ─── Class starting stats & backgrounds ──────────────────────────────────────

const CLASS_STATS: Record<string, Stats> = {
  Warrior:     { hp: 100, maxHp: 100, strength: 8, cunning: 3, will: 4, reputation: 5 },
  Rogue:       { hp:  70, maxHp:  70, strength: 4, cunning: 9, will: 3, reputation: 3 },
  Mage:        { hp:  60, maxHp:  60, strength: 2, cunning: 6, will: 9, reputation: 5 },
  Paladin:     { hp:  90, maxHp:  90, strength: 7, cunning: 3, will: 8, reputation: 7 },
  Ranger:      { hp:  80, maxHp:  80, strength: 6, cunning: 7, will: 5, reputation: 4 },
  Necromancer: { hp:  65, maxHp:  65, strength: 3, cunning: 6, will: 8, reputation: 2 },
  Bard:        { hp:  70, maxHp:  70, strength: 3, cunning: 8, will: 6, reputation: 7 },
  Druid:       { hp:  75, maxHp:  75, strength: 5, cunning: 5, will: 8, reputation: 4 },
  전사:         { hp: 100, maxHp: 100, strength: 8, cunning: 3, will: 4, reputation: 5 },
  도적:         { hp:  70, maxHp:  70, strength: 4, cunning: 9, will: 3, reputation: 3 },
  마법사:       { hp:  60, maxHp:  60, strength: 2, cunning: 6, will: 9, reputation: 5 },
  성기사:       { hp:  90, maxHp:  90, strength: 7, cunning: 3, will: 8, reputation: 7 },
  레인저:       { hp:  80, maxHp:  80, strength: 6, cunning: 7, will: 5, reputation: 4 },
  사령술사:     { hp:  65, maxHp:  65, strength: 3, cunning: 6, will: 8, reputation: 2 },
  음유시인:     { hp:  70, maxHp:  70, strength: 3, cunning: 8, will: 6, reputation: 7 },
  드루이드:     { hp:  75, maxHp:  75, strength: 5, cunning: 5, will: 8, reputation: 4 },
};

const DEFAULT_STATS: Stats = { hp: 75, maxHp: 75, strength: 5, cunning: 5, will: 5, reputation: 5 };

const CLASS_BACKGROUNDS: Record<string, { location: string; background: string }> = {
  Warrior: {
    location: "the blood-soaked front lines of a crumbling fortress",
    background: "You are a seasoned warrior, scarred from a hundred battles. Your regiment was slaughtered last night — you alone survived. The fortress gates are failing.",
  },
  Rogue: {
    location: "the rain-slicked rooftops of a corrupt city",
    background: "You are a rogue who just stole something you shouldn't have. The thieves' guild wants it back. The city guard wants you dead. You have one hour before dawn.",
  },
  Mage: {
    location: "the ruins of a forbidden arcane tower",
    background: "You are a mage who broke into a sealed tower seeking lost knowledge. The spell you cast to open it awakened something. Now the tower door won't open from the inside.",
  },
  Paladin: {
    location: "a desecrated cathedral at the edge of the cursed lands",
    background: "You are a paladin sent alone to investigate why prayers from this region have gone silent. Inside the cathedral, the holy symbols have been reversed. Something breathes in the dark.",
  },
  Ranger: {
    location: "a dying forest at the border of the known world",
    background: "You are a ranger who has tracked a creature for three days through a forest that is rotting from the inside. The tracks stop here — at a clearing where the trees have been arranged into a symbol.",
  },
  Necromancer: {
    location: "a collapsed crypt beneath an ancient city",
    background: "You are a necromancer whose ritual went wrong. You were trying to bind a single spirit. Instead, something far older answered. The crypt has sealed itself. The dead are stirring.",
  },
  Bard: {
    location: "a crossroads tavern at the edge of a war zone",
    background: "You are a bard who overheard a secret conversation between two generals — a plan that would end thousands of lives. Both men saw your face. You need to decide what to do with what you know.",
  },
  Druid: {
    location: "an ancient stone circle deep in a poisoned wilderness",
    background: "You are a druid who felt the land scream three nights ago. You followed the wound to its source: this circle, where the stones pulse with unnatural light. The animals flee. Only you stay.",
  },
  전사: {
    location: "무너져가는 요새의 피로 물든 최전선",
    background: "당신은 백 번의 전투에서 살아남은 노련한 전사입니다. 어젯밤 당신의 부대가 전멸했습니다 — 살아남은 건 오직 당신뿐입니다. 요새의 문이 무너지고 있습니다.",
  },
  도적: {
    location: "부패한 도시의 빗속 지붕 위",
    background: "당신은 훔쳐서는 안 될 것을 훔친 도적입니다. 도적 길드는 그것을 되찾으려 하고, 시위대는 당신을 죽이려 합니다. 새벽까지 한 시간이 남았습니다.",
  },
  마법사: {
    location: "금지된 마탑의 폐허",
    background: "당신은 잃어버린 지식을 찾아 봉인된 탑에 잠입한 마법사입니다. 문을 열기 위해 시전한 주문이 무언가를 깨웠습니다. 이제 탑의 문이 안에서 열리지 않습니다.",
  },
  성기사: {
    location: "저주받은 땅 끝에 있는 훼손된 대성당",
    background: "당신은 이 지역의 기도가 왜 침묵했는지 단독으로 조사하러 파견된 성기사입니다. 성당 안에는 성스러운 상징들이 뒤집혀 있습니다. 어둠 속에서 무언가가 숨 쉬고 있습니다.",
  },
  레인저: {
    location: "알려진 세계의 경계, 죽어가는 숲",
    background: "당신은 사흘째 내부에서 썩어가는 숲을 통해 어떤 존재를 추적해온 레인저입니다. 발자국이 여기서 끊겼습니다 — 나무들이 어떤 문양으로 배열된 공터에서.",
  },
  사령술사: {
    location: "고대 도시 아래에 무너진 납골당",
    background: "당신은 의식이 잘못된 사령술사입니다. 하나의 영혼을 결박하려 했지만, 훨씬 오래된 무언가가 응답했습니다. 납골당이 스스로 봉인되었습니다. 죽은 자들이 깨어나고 있습니다.",
  },
  음유시인: {
    location: "전쟁 지대 끝에 있는 사거리 선술집",
    background: "당신은 두 장군 사이의 비밀 대화를 엿들은 음유시인입니다 — 수천 명의 목숨을 앗아갈 계획. 두 사람 모두 당신의 얼굴을 봤습니다. 이 정보로 무엇을 할지 결정해야 합니다.",
  },
  드루이드: {
    location: "독에 물든 황야 깊숙이 있는 고대 돌 원형제단",
    background: "당신은 사흘 전 밤 땅이 비명 지르는 것을 느꼈습니다. 그 상처의 근원을 따라 여기까지 왔습니다. 돌들이 부자연스러운 빛으로 맥동하고 있습니다. 동물들은 도망쳤습니다. 오직 당신만 남아 있습니다.",
  },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function buildChoiceLog(
  entries: Array<{ entryType: string; content: string; choiceIndex: number | null }>,
  lang: string
): string {
  const choices = entries.filter((e) => e.entryType === "choice");
  if (choices.length === 0) return "";
  const header = lang === "ko" ? "=== 플레이어 선택 기록 ===\n" : "=== PLAYER DECISION LOG ===\n";
  const lines = choices.map((c, i) => {
    const text = c.content.replace(/^I choose: /i, "").replace(/^선택: /, "");
    return `${i + 1}. ${text}`;
  });
  return header + lines.join("\n");
}

function applyStatChanges(current: Stats, changes: StatChanges): Stats {
  const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
  return {
    hp:         clamp(current.hp + (changes.hp ?? 0), 0, current.maxHp),
    maxHp:      current.maxHp,
    strength:   clamp(current.strength   + (changes.strength   ?? 0), 1, 10),
    cunning:    clamp(current.cunning    + (changes.cunning    ?? 0), 1, 10),
    will:       clamp(current.will       + (changes.will       ?? 0), 1, 10),
    reputation: clamp(current.reputation + (changes.reputation ?? 0), 1, 10),
  };
}

function buildStatsContext(stats: Stats, lang: string): string {
  if (lang === "ko") {
    return `=== 현재 플레이어 스탯 ===
생명력: ${stats.hp}/${stats.maxHp}${stats.hp < 20 ? " [위험 — 빈사 상태]" : stats.hp < 40 ? " [경고 — 부상 중]" : ""}
힘: ${stats.strength}/10
교활함: ${stats.cunning}/10
의지: ${stats.will}/10
명성: ${stats.reputation}/10`;
  }
  return `=== CURRENT PLAYER STATS ===
HP: ${stats.hp}/${stats.maxHp}${stats.hp < 20 ? " [CRITICAL — near death]" : stats.hp < 40 ? " [WARNING — wounded]" : ""}
Strength: ${stats.strength}/10
Cunning: ${stats.cunning}/10
Will: ${stats.will}/10
Reputation: ${stats.reputation}/10`;
}

function buildDiceContext(roll: RollResult, choiceText: string, lang: string): string {
  const outcomeLabel = lang === "ko"
    ? OUTCOME_CONTEXT_KO[roll.outcome]
    : OUTCOME_CONTEXT_EN[roll.outcome];
  const modSign = roll.modifier >= 0 ? `+${roll.modifier}` : `${roll.modifier}`;

  if (lang === "ko") {
    const statNames: Record<string, string> = {
      strength: "힘", cunning: "교활함", will: "의지", reputation: "명성",
    };
    return `=== 주사위 굴림 결과 ===
플레이어 행동: "${choiceText}"
원래 d20 굴림: ${roll.raw}
관련 스탯: ${statNames[roll.stat] ?? roll.stat} (${roll.statValue}/10)
스탯 보정: ${modSign}
최종 합계: ${roll.total}/20
결과: ${outcomeLabel}
위 결과를 서사에 명확히 반영하세요.`;
  }

  return `=== DICE ROLL ===
Player action: "${choiceText}"
d20 roll: ${roll.raw}
Relevant stat: ${roll.stat} (${roll.statValue}/10)
Stat modifier: ${modSign}
Total: ${roll.total}/20
Outcome: ${outcomeLabel}
Reflect this outcome clearly in your narration.`;
}

async function generateStory(
  history: Array<{ role: "user" | "assistant"; content: string }>,
  genre: string,
  lang: string,
  statsContext: string,
  choiceLog: string,
  diceContext: string
): Promise<{ narration: string; choices: string[]; statChanges?: StatChanges; isEnding?: boolean }> {
  const systemPrompt = lang === "ko" ? SYSTEM_PROMPT_KO : SYSTEM_PROMPT_EN;
  const genreExtra = genre !== "fantasy"
    ? (lang === "ko" ? ` 장르는 ${genre}입니다.` : ` The genre is ${genre}.`)
    : "";

  const contextBlocks = [systemPrompt + genreExtra, statsContext, choiceLog, diceContext]
    .filter(Boolean)
    .join("\n\n");

  const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
    { role: "system", content: contextBlocks },
    ...history,
  ];

  const response = await openai.chat.completions.create({
    model: "gpt-5.2",
    messages,
    max_completion_tokens: 8192,
    response_format: { type: "json_object" },
  });

  const content = response.choices[0]?.message?.content || "{}";
  const parsed = JSON.parse(content);

  return {
    narration:   parsed.narration || (lang === "ko" ? "이야기가 계속됩니다..." : "The story continues..."),
    choices:     Array.isArray(parsed.choices) ? parsed.choices.slice(0, 3) : [],
    statChanges: parsed.statChanges || {},
    isEnding:    parsed.isEnding || false,
  };
}

// ─── Routes ───────────────────────────────────────────────────────────────────

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.post("/api/game/start", async (req: Request, res: Response) => {
    try {
      const { genre = "fantasy", characterName, characterClass, lang = "en" } = req.body;

      const session = await storage.createGameSession({
        title: `${characterName || "Hero"}'s ${genre} adventure`,
        genre,
        status: "active",
      });

      const initialStats: Stats = characterClass
        ? (CLASS_STATS[characterClass] ?? { ...DEFAULT_STATS })
        : { ...DEFAULT_STATS };
      await storage.setStats(session.id, initialStats);
      await storage.setPlayerMeta(session.id, {
        name: characterName || "",
        characterClass: characterClass || "",
      });

      const classBg = characterClass ? CLASS_BACKGROUNDS[characterClass] : null;

      let startPrompt: string;
      if (lang === "ko") {
        startPrompt = classBg
          ? [
              `새로운 ${genre} 모험을 시작합니다.`,
              characterName ? `플레이어의 이름은 ${characterName}입니다.` : "",
              `직업: ${characterClass}`,
              `시작 위치: ${classBg.location}`,
              `배경: ${classBg.background}`,
              `위 배경을 자연스럽게 녹여서 오프닝 서사를 작성하고 첫 번째 선택지 3개를 제시하세요. 첫 장면이므로 statChanges는 모두 0으로 반환하세요.`,
            ].filter(Boolean).join("\n")
          : `새로운 ${genre} 모험을 시작합니다. statChanges는 모두 0으로 반환하세요.`;
      } else {
        startPrompt = classBg
          ? [
              `Begin a new ${genre} adventure.`,
              characterName ? `The player's name is ${characterName}.` : "",
              `Class: ${characterClass}`,
              `Starting location: ${classBg.location}`,
              `Background: ${classBg.background}`,
              `Weave this background into the opening narration, present 3 starting choices. Return all statChanges as 0.`,
            ].filter(Boolean).join("\n")
          : `Begin a new ${genre} adventure. Set the opening scene. Return all statChanges as 0.`;
      }

      const statsContext = buildStatsContext(initialStats, lang);
      const result = await generateStory(
        [{ role: "user", content: startPrompt }],
        genre, lang, statsContext, "", ""
      );

      await storage.createStoryEntry({
        sessionId: session.id,
        entryType: "narration",
        content: JSON.stringify(result),
        choiceIndex: null,
      });

      await storage.updateGameSession(session.id, { turnCount: 1 });
      res.json({ sessionId: session.id, ...result, stats: initialStats });
    } catch (error) {
      console.error("Error starting game:", error);
      res.status(500).json({ message: "Failed to start game" });
    }
  });

  app.post("/api/game/:id/choice", async (req: Request, res: Response) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { choiceIndex, choiceText, lang = "en" } = req.body;

      const session = await storage.getGameSession(sessionId);
      if (!session) return res.status(404).json({ message: "Session not found" });

      const currentStats = await storage.getStats(sessionId) ?? { ...DEFAULT_STATS };

      // Roll dice before AI call
      const roll = computeRoll(choiceText, currentStats);

      const entries = await storage.getStoryEntries(sessionId);

      const history: Array<{ role: "user" | "assistant"; content: string }> = [];
      for (const entry of entries) {
        if (entry.entryType === "narration") {
          const data = JSON.parse(entry.content);
          history.push({
            role: "assistant",
            content: JSON.stringify({ narration: data.narration, choices: data.choices }),
          });
        } else if (entry.entryType === "choice") {
          history.push({ role: "user", content: entry.content });
        }
      }

      const choiceMessage = lang === "ko" ? `선택: ${choiceText}` : `I choose: ${choiceText}`;
      history.push({ role: "user", content: choiceMessage });

      await storage.createStoryEntry({
        sessionId,
        entryType: "choice",
        content: choiceMessage,
        choiceIndex,
      });

      const updatedEntries = await storage.getStoryEntries(sessionId);
      const choiceLog  = buildChoiceLog(updatedEntries, lang);
      const statsContext = buildStatsContext(currentStats, lang);
      const diceContext  = buildDiceContext(roll, choiceText, lang);

      const result = await generateStory(history, session.genre, lang, statsContext, choiceLog, diceContext);

      const newStats = applyStatChanges(currentStats, result.statChanges ?? {});
      await storage.setStats(sessionId, newStats);

      const isDead   = newStats.hp <= 0;
      const isEnding = result.isEnding || isDead;

      await storage.createStoryEntry({
        sessionId,
        entryType: "narration",
        content: JSON.stringify({ ...result, isEnding }),
        choiceIndex: null,
      });

      await storage.updateGameSession(sessionId, {
        turnCount: session.turnCount + 1,
        status: isEnding ? "completed" : "active",
      });

      res.json({ ...result, roll, isEnding, stats: newStats });
    } catch (error) {
      console.error("Error processing choice:", error);
      res.status(500).json({ message: "Failed to process choice" });
    }
  });

  app.get("/api/game/:id", async (req: Request, res: Response) => {
    try {
      const sessionId = parseInt(req.params.id);
      const session = await storage.getGameSession(sessionId);
      if (!session) return res.status(404).json({ message: "Session not found" });
      const entries    = await storage.getStoryEntries(sessionId);
      const stats      = await storage.getStats(sessionId);
      const playerMeta = await storage.getPlayerMeta(sessionId);
      res.json({ session, entries, stats, playerMeta });
    } catch (error) {
      res.status(500).json({ message: "Failed to get game" });
    }
  });

  app.get("/api/games", async (_req: Request, res: Response) => {
    try {
      const sessions = await storage.listGameSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to list games" });
    }
  });

  return httpServer;
}
