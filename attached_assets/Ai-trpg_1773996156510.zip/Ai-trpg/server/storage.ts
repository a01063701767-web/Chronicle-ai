import {
  type GameSession,
  type InsertGameSession,
  type StoryEntry,
  type InsertStoryEntry,
  type Stats,
} from "@shared/schema";

export type PlayerMeta = { name: string; characterClass: string };

export interface IStorage {
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  getGameSession(id: number): Promise<GameSession | undefined>;
  listGameSessions(): Promise<GameSession[]>;
  updateGameSession(id: number, updates: Partial<GameSession>): Promise<GameSession | undefined>;
  createStoryEntry(entry: InsertStoryEntry): Promise<StoryEntry>;
  getStoryEntries(sessionId: number): Promise<StoryEntry[]>;
  getStats(sessionId: number): Promise<Stats | undefined>;
  setStats(sessionId: number, stats: Stats): Promise<Stats>;
  getPlayerMeta(sessionId: number): Promise<PlayerMeta | undefined>;
  setPlayerMeta(sessionId: number, meta: PlayerMeta): Promise<void>;
}

export class MemStorage implements IStorage {
  private sessions    = new Map<number, GameSession>();
  private entries     = new Map<number, StoryEntry>();
  private statsMap    = new Map<number, Stats>();
  private playerMetas = new Map<number, PlayerMeta>();
  private sessionId   = 1;
  private entryId     = 1;

  async createGameSession(session: InsertGameSession): Promise<GameSession> {
    const id  = this.sessionId++;
    const now = new Date();
    const row: GameSession = {
      id,
      title:     session.title     ?? "Adventure",
      genre:     session.genre     ?? "fantasy",
      status:    session.status    ?? "active",
      turnCount: 0,
      createdAt: now,
      updatedAt: now,
    };
    this.sessions.set(id, row);
    return row;
  }

  async getGameSession(id: number) { return this.sessions.get(id); }

  async listGameSessions(): Promise<GameSession[]> {
    return [...this.sessions.values()].sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async updateGameSession(id: number, updates: Partial<GameSession>) {
    const s = this.sessions.get(id);
    if (!s) return undefined;
    const updated = { ...s, ...updates, updatedAt: new Date() };
    this.sessions.set(id, updated);
    return updated;
  }

  async createStoryEntry(entry: InsertStoryEntry): Promise<StoryEntry> {
    const id  = this.entryId++;
    const now = new Date();
    const row: StoryEntry = {
      id,
      sessionId:   entry.sessionId,
      entryType:   entry.entryType,
      content:     entry.content,
      choiceIndex: entry.choiceIndex ?? null,
      createdAt:   now,
    };
    this.entries.set(id, row);
    return row;
  }

  async getStoryEntries(sessionId: number): Promise<StoryEntry[]> {
    return [...this.entries.values()]
      .filter((e) => e.sessionId === sessionId)
      .sort((a, b) => a.id - b.id);
  }

  async getStats(sessionId: number) { return this.statsMap.get(sessionId); }

  async setStats(sessionId: number, stats: Stats): Promise<Stats> {
    this.statsMap.set(sessionId, stats);
    return stats;
  }

  async getPlayerMeta(sessionId: number) { return this.playerMetas.get(sessionId); }

  async setPlayerMeta(sessionId: number, meta: PlayerMeta): Promise<void> {
    this.playerMetas.set(sessionId, meta);
  }
}

export const storage = new MemStorage();
